package ejercicio;

public class Image {
	
	private int id=0;
	
	private String urlImg="";
	
	private String dirImg="";

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String getUrlImg() {
		return urlImg;
	}

	public void setUrlImg(String urlImg) {
		this.urlImg = urlImg;
	}

	public String getDirImg() {
		return dirImg;
	}

	public void setDirImg(String dirImg) {
		this.dirImg = dirImg;
	}

}
