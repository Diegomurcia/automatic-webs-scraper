package webscraping;

public class ImageToCsvTest {

}
